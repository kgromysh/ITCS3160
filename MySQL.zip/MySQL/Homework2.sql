/* HOMEWORK #2 TEMPLATE */

/*
  Use this template to format your submission for homework #2.  Be sure
  to put your SQL statements in the areas indicated below.
  See the homework assignment for specific directions on what is needed.
  Please follow the format specified.  This is necessary to make grading
  easier and more efficient.  Failure to follow this template will result
  in a deduction to your grade for this assignment.
*/

/********  SECTION FOR DATABASE # 1  ******************************************/
/* Put the SQL code to create Database #1 just after this comment */

DROP DATABASE Vehicles

CREATE DATABASE Vehicles
GO
/* Put the SQL code to create the 1st table for Database #1 just after this comment */
USE Vehicles
GO

DROP TABLE CostOfVehicle
GO

CREATE TABLE CostOfVehicle(
Make varchar(10) NOT NULL,
cost float(2) NOT NULL,
VinNumber varchar(17) NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 1st table for Database #1 just after this comment */
INSERT INTO CostOfVehicle(Make, cost, VinNumber)
VALUES('Toyota',4500.00 ,'23R67GR4JK124569I')
GO

INSERT INTO CostOfVehicle(Make, cost, VinNumber)
VALUES('Ford', 6560.00,'78R67JR4JK124569I')
GO

INSERT INTO CostOfVehicle(Make, cost, VinNumber)
VALUES('Honda', 7800.00,'83K67GR4B9124539I')
GO

/* Put the SQL code to create the 2nd table for Database #1 just after this comment */

DROP TABLE CarModel/*IT can re-create the table if it exists*/
GO

CREATE TABLE CarModel(
ModelType char(10) NOT NULL,
Make char(10) NOT NULL,
MPG int NOT NULL,
)
GO

/* Put the SQL code to insert data into the the 2nd table for Database #1 just after this comment */
INSERT INTO CarModel(ModelType, Make, MPG)
VALUES ('Toyota', 'Prais', 23)
GO

INSERT INTO CarModel(ModelType, Make, MPG)
VALUES ('Ford','Dart' , 40)
GO

INSERT INTO CarModel(ModelType, Make, MPG)
VALUES ('Porsche','Boxer', 28)
GO

/* Put the SQL code to create the 3rd table for Database #1 just after this comment */
DROP TABLE CarMake
GO

CREATE TABLE CarMake(
MakeType varchar(10) NOT NULL,
DatePurchased date NOT NULL,
Color varchar(15) NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 3rd table for Database #1 just after this comment */
INSERT INTO CarMake (MakeType, DatePurchased, Color)
VAlUES ('Toyota', '03/31/2010','Blue')
Go

INSERT INTO CarMake (MakeType, DatePurchased, Color)
VAlUES ('Nessan', '04/24/2012','Red')
Go

INSERT INTO CarMake (MakeType, DatePurchased, Color)
VAlUES ('Jeep', '08/27/2008','Green')
Go

/********  SECTION FOR DATABASE # 2  ******************************************/
/* Put the SQL code to create Database #2 just after this comment */
DROP DATABASE CandyShoppe
GO

CREATE DATABASE CandyShoppe
GO

USE CandyShoppe
GO
/* Put the SQL code to create the 1st table for Database #2 just after this comment */

DROP TABLE TypesOfCandy
GO

CREATE TABLE TypesOfCandy(
CandyTypes varchar(10) NOT NULL,
NetWeight float(2) NOT NULL,
CostByWeight float(20)  NOT NULL,
)
GO

/* Put the SQL code to insert data into the the 1st table for Database #2 just after this comment */
INSERT INTO TypesOfCandy(CandyTypes,NetWeight,CostByWeight)
VALUES('Chocolate', 1.20, .78)
GO

INSERT INTO TypesOfCandy(CandyTypes,NetWeight,CostByWeight)
VALUES('HardCandy', 2.5, .23)
GO

INSERT INTO TypesOfCandy(CandyTypes,NetWeight,CostByWeight)
VALUES('Gummie', 5.49, .56)
GO
/* Put the SQL code to create the 2nd table for Database #2 just after this comment */
DROP TABLE AllergyFriendlyCandy
GO

CREATE TABLE AllergyFriendlyCandy(
TypeOfCandy varchar(10) NOT NULL,
Allergy     text        NOT NULL,
Expires     date        NOT NULL,
)
GO 
/* Put the SQL code to insert data into the the 2nd table for Database #2 just after this comment */
INSERT INTO  AllergyFriendlyCandy(TypeOfCandy,Allergy,Expires)
VALUES('Chocolate', 'GlutenFree', '08/31/2016')
GO

INSERT INTO  AllergyFriendlyCandy(TypeOfCandy,Allergy,Expires)
VALUES('Gummie', 'DairyFree', '09/12/2016')
GO

INSERT INTO  AllergyFriendlyCandy(TypeOfCandy,Allergy,Expires)
VALUES('HardCandy', 'CornFree', '10/27/2016')
GO
/* Put the SQL code to create the 3rd table for Database #2 just after this comment */

DROP TABLE Inventory
GO

CREATE TABLE Inventory(
TypeOfCandy varchar(10) NOT NULL,
InStock     int        NOT NULL,
Expires     date        NOT NULL,
)
GO 
/* Put the SQL code to insert data into the the 3rd table for Database #2 just after this comment */
INSERT INTO  Inventory(TypeOfCandy,InStock,Expires)
VALUES('Chocolate', 37, '08/31/2016')
GO

INSERT INTO  Inventory(TypeOfCandy,InStock,Expires)
VALUES('Gummie', 45, '09/12/2016')
GO

INSERT INTO  Inventory(TypeOfCandy,InStock,Expires)
VALUES('HardCandy', 89, '10/27/2016')
GO

/********  SECTION FOR DATABASE # 3  ******************************************/
/* Put the SQL code to create Database #3 just after this comment */
DROP DATABASE University
GO

CREATE DATABASE University
GO

USE University
GO
/* Put the SQL code to create the 1st table for Database #3 just after this comment */
DROP TABLE SchoolLocation
GO

CREATE TABLE SchoolLacation(
SchoolName varchar(25) NOT NULL,
City varchar(12) NOT NULL,
YearEstablished int NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 1st table for Database #3 just after this comment */
INSERT INTO SchoolLacation(SchoolName, City, YearEstablished)
VALUES('Harverd', 'Cambridge', 1636)
GO

INSERT INTO SchoolLacation(SchoolName, City, YearEstablished)
VALUES('Yale', 'New Haven', 1701)
GO

INSERT INTO SchoolLacation(SchoolName, City, YearEstablished)
VALUES('UNCC', 'Charlotte', 1946)
GO
/* Put the SQL code to create the 2nd table for Database #3 just after this comment */
DROP TABLE CostToMaintain
GO

CREATE TABLE CostToMaintain(
SchoolName varchar(25) NOT NULL,
ElectricityPerHour float(2) NOT NULL,
HoursUsed int NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 2nd table for Database #3 just after this comment */
INSERT INTO CostToMaintain(SchoolName, ElectricityPerHour, HoursUsed)
VALUES('Harverd', .21, 1890)
GO

INSERT INTO CostToMaintain(SchoolName, ElectricityPerHour, HoursUsed)
VALUES('Yale', .12, 2701)
GO

INSERT INTO CostToMaintain(SchoolName, ElectricityPerHour, HoursUsed)
VALUES('UNCC', .11, 1790)
GO
/* Put the SQL code to create the 3rd table for Database #3 just after this comment */

DROP TABLE Courses
GO

CREATE TABLE Courses(
SchoolName varchar(25) NOT NULL,
CourseId int NOT NULL,
HoursInClass float(2) NOT NULL,
)
GO

/* Put the SQL code to insert data into the the 3rd table for Database #3 just after this comment */
INSERT INTO Courses(SchoolName, CourseId, HoursInClass)
VALUES('Harverd', 1423, 2.5)
GO

INSERT INTO Courses(SchoolName, CourseId, HoursInClass)
VALUES('Yale', 2175, 2.25)
GO

INSERT INTO Courses(SchoolName, CourseId, HoursInClass)
VALUES('UNCC', 3160, 1.0)
GO

/********  SECTION FOR DATABASE # 4  ******************************************/
/* Put the SQL code to create Database #4 just after this comment */
DROP DATABASE Transportation
GO

CREATE DATABASE Transportation
GO

USE Transportation
GO
/* Put the SQL code to create the 1st table for Database #4 just after this comment */

DROP  TABLE TransportationType
GO

CREATE TABLE TransportationType(
TransportType varchar(15) NOT NULL,
MilesTraveledDaily int NOT NULL,
City Varchar(15) NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 1st table for Database #4 just after this comment */
INSERT INTO TransportationType(TransportType,MilesTraveledDaily,City)
VALUES('BUS',6,'Boston')
GO

INSERT INTO TransportationType(TransportType,MilesTraveledDaily,City)
VALUES('Car',7,'Salem')
GO

INSERT INTO TransportationType(TransportType,MilesTraveledDaily,City)
VALUES('Bicycle',8,'Portand')
GO
/* Put the SQL code to create the 2nd table for Database #4 just after this comment */
DROP TABLE CostForTransportation
GO

CREATE TABLE CostForTransportation(
TransportType varchar(7) NOT NULL,
MilesTraveledDaily int NOT NULL,
Cost float(2) NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 2nd table for Database #4 just after this comment */
INSERT INTO CostForTransportation(TransportType,MilesTraveledDaily,Cost)
VALUES('Bus',12, 120.00)
GO

INSERT INTO CostForTransportation(TransportType,MilesTraveledDaily,Cost)
VALUES('Car',24, 320.00)
GO

INSERT INTO CostForTransportation(TransportType,MilesTraveledDaily,Cost)
VALUES('Bicycle',5, 10.00)
GO
/* Put the SQL code to create the 3rd table for Database #4 just after this comment */
DROP TABLE PreferredTransportation
GO

CREATE TABLE PreferredTransportation(
City varchar(25) NOT NULL,
TypeOfWork text  NOT NULL,
MilesTraveledDaily int NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 3rd table for Database #4 just after this comment */
INSERT INTO PreferredTransportation(City,TypeOfWork,MilesTraveledDaily)
VALUES('Amsterdam','School Teacher',4)
GO

INSERT INTO PreferredTransportation(City,TypeOfWork,MilesTraveledDaily)
VALUES('Paris','Retail',8)
GO

INSERT INTO PreferredTransportation(City,TypeOfWork,MilesTraveledDaily)
VALUES('London','Chemistry Engineer',16)
GO 

/********  SECTION FOR DATABASE # 5  ******************************************/
/* Put the SQL code to create Database #5 just after this comment */
DROP DATABASE CheeseFactory
GO

CREATE DATABASE CheeseFactory
GO

USE CheeseFactory
GO
/* Put the SQL code to create the 1st table for Database #5 just after this comment */
DROP TABLE  CheeseProduction
GO

CREATE TABLE CheeseProduction(
DayOfTheWeek varchar(10) NOT NULL,
PoundsOfCheeseProduced float(2) NOT NULL,
HoursInOperation int NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 1st table for Database #5 just after this comment */
INSERT INTO CheeseProduction(DayOfTheWeek,PoundsOfCheeseProduced,HoursInOperation)
VALUES('Monday',458.5,12)
GO

INSERT INTO CheeseProduction(DayOfTheWeek,PoundsOfCheeseProduced,HoursInOperation)
VALUES('Thursday',558.6,10)
GO

INSERT INTO CheeseProduction(DayOfTheWeek,PoundsOfCheeseProduced,HoursInOperation)
VALUES('Friday',358.4,8)
GO
/* Put the SQL code to create the 2nd table for Database #5 just after this comment */
DROP TABLE Employee
GO

CREATE TABLE Employee(
Name varchar(15) NOT NULL,
HoursWorked float(3) NOT NULL,
HourlyPay float(3) NOT NULL,
)
GO
/* Put the SQL code to insert data into the the 2nd table for Database #5 just after this comment */
INSERT INTO Employee(Name,HoursWorked,HourlyPay)
VALUES('Katie',25.0, 12.0)
GO

INSERT INTO Employee(Name,HoursWorked,HourlyPay)
VALUES('BOB',35.00, 13.00)
GO

INSERT INTO Employee(Name,HoursWorked,HourlyPay)
VALUES('Susan',40.00, 15.00)
GO
/* Put the SQL code to create the 3rd table for Database #5 just after this comment */
DROP TABLE CheeseType
GO

CREATE TABLE CheeseType(
CheeseType varchar(15) NOT NULL,
age  varchar(15) NOT NULL,
DaysItsMade varchar(15) NOT NULL,
)
/* Put the SQL code to insert data into the the 3rd table for Database #5 just after this comment */
INSERT INTO CheeseType(CheeseType,age,DaysItsMAde)
VAlUES('Chedder', '2 years', 'Monday')
GO

INSERT INTO CheeseType(CheeseType,age,DaysItsMAde)
VAlUES('American', '2 months', 'Tuesday')
GO

INSERT INTO CheeseType(CheeseType,age,DaysItsMAde)
VAlUES('Harvarty', ' 4 months', 'Friday')
GO
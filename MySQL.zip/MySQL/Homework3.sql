
DROP TABLE SeniorityOfEmployee  
GO

DROP TABLE ScholarShipContest
GO

DROP TABLE GymMembership
GO

DROP TABLE SimpsonCharacters
GO

AlTER TABLE ClassRegistration 
DROP CONSTRAINT FK_ClassRegistration_Students
GO

ALTER TABLE ClassRegistration
DROP CONSTRAINT FK_ClassRegistration_Courses
GO

DROP TABLE Students
GO

DROP TABLE Courses
GO



DROP  TABLE ClassRegistration
GO

USE master
GO

DROP DATABASE EmployeeInformation
GO

/*CREATE DATABASE EmployeeInformation
GO
USE EmployeeInformation
GO*/

/*1 Table that demonstrates the required constraint*/

CREATE TABLE SeniorityOfEmployee(
Name varchar(50) ,
YearsWorked int NOT NULL,
Salary float(2) NOT NULL,
)
GO

INSERT INTO SeniorityOfEmployee(Name,YearsWorked,Salary)/*Example of a constraint pass*/
VALUES('James Bond', 5, 78000.00)
GO

INSERT INTO SeniorityOfEmployee(Name,YearsWorked,Salary)/*Example of a constraint fail*/
VALUES(' Tom Smith', 4, Null)
GO

INSERT INTO SeniorityOfEmployee(Name,YearsWorked,Salary)/*Example of a constraint fail*/
VALUES(' Anna Hopkins', NULL, 109000.00)
GO

/*2 A table that includes both a field level check and a table level check.*/
CREATE TABLE ScholarShipContest(
Name varchar(50),
ExamScore int,
ClubsJoined int,

CONSTRAINT ck_ExamScore CHECK (ExamScore>350),
CONSTRAINT ck_ExamScoreAndClubsJoined CHECK((ExamScore >400) OR (ClubsJoined >5)),
)
GO

INSERT INTO ScholarShipContest(Name,ExamScore,ClubsJoined)
VALUES('Tiffany',360, 6)
GO

INSERT INTO ScholarShipContest(Name,ExamScore,ClubsJoined)/* Meets the Feild level check but not table level check*/
VALUES('Penny',355, 0)
GO

INSERT INTO ScholarShipContest(Name,ExamScore,ClubsJoined)/* Dosen't Meet the Feild level check but meets table level check*/
VALUES('Eduard',280, 8)
GO

/*3. A table that defines a primary key constraint.*/
CREATE TABLE GymMembership(
CustomerID int,
Name varchar(50),
Location text ,

CONSTRAINT PK_GymMembership PRIMARY KEY CLUSTERED
   (CustomerID ASC)
)
GO
INSERT INTO GymMembership(CustomerID, Name, Location)
VALUES(5284537,'Barry Wite','Springfeild')
GO
INSERT INTO GymMembership(CustomerID, Name, Location)
VALUES(1334567,'Jenny Jones','Portland')
GO
INSERT INTO GymMembership(CustomerID, Name, Location)
VALUES(1334567,'Tiffany Roberts','Miami')
GO

/*4 A table that defines a unique constraint.*/

CREATE TABLE SimpsonCharacters(
CharacterName varchar(50),
Person varchar(50),
ActorID int,

CONSTRAINT PK_SimpsonCharacters PRIMARY KEY CLUSTERED
   (ActorID ASC),
CONSTRAINT UK_SimpsonCharacters UNIQUE 
   (Person ASC)
)
GO

INSERT INTO SimpsonCharacters(CharacterName,Person,ActorID)
VALUES( 'Homer','Dan Castellaneta',12345678)
GO

INSERT INTO SimpsonCharacters(CharacterName,Person,ActorID)
VALUES( 'Lisa','Dan Castellaneta',123345678)
GO

INSERT INTO SimpsonCharacters(CharacterName,Person,ActorID)
VALUES( 'Marge','Julie Kavner ',13425678)
GO

/*5. Three tables: Students, Classes, and ClassRegistration*/


CREATE TABLE Students (
StudentID int,
Name varchar(50),
Major text
CONSTRAINT PK_Students PRIMARY KEY CLUSTERED
   (StudentID ASC)
)
GO

INSERT INTO Students(StudentID,Name,Major)
VALUES(12345678,'Tommy', 'Engineering')
GO

INSERT INTO Students(StudentID,Name,Major)
VALUES(78923456,'Diane', 'Chemistry')
GO

INSERT INTO Students(StudentID,Name,Major)
VALUES(24923457,'Lisa', 'Nursing')
GO



CREATE TABLE Courses(
CourseId int,
CourseName varchar(50),
CourseDescription text,

CONSTRAINT PK_Courses PRIMARY KEY 
  (CourseId ASC)
)
GO

INSERT INTO Courses(CourseId,CourseName, CourseDescription)
VALUES(2341,'Engineering','Electrical')
GO

INSERT INTO Courses(CourseId,CourseName, CourseDescription)
VALUES(4141,'Science','Chemical')



INSERT INTO Courses(CourseId,CourseName, CourseDescription)
VALUES(1041,'Nusring','Surgical')



CREATE TABLE ClassRegistration(
StudentName varchar(50),
StudentID int,
CourseName varchar(50),
CourseId int,

CONSTRAINT PK_ClassRegistration PRIMARY KEY
(StudentID ASC,CourseId ASC),

CONSTRAINT FK_ClassRegistration_Students FOREIGN KEY (StudentID)
REFERENCES Students (StudentID) ON DELETE CASCADE,

CONSTRAINT FK_ClassRegistration_Courses FOREIGN KEY (CourseID)
REFERENCES Courses (CourseID) ON DELETE NO ACTION
)
GO 


INSERT INTO ClassRegistration(StudentName,StudentID,CourseName,CourseId)
VALUES('Tommy',12345678, 'Engineering',2341)
GO

INSERT INTO ClassRegistration(StudentName,StudentID,CourseName,CourseId)
VALUES('Lisa',24923457, 'Nursing', 1041)
GO

INSERT INTO ClassRegistration(StudentID,StudentName,CourseName,CourseId)
VALUES(78923456,'Diane', 'Chemistry',4141)
GO

/*DELETE FROM Students
WHERE StudentID=78923456
GO

DELETE FROM Courses
WHERE CourseId=1041
GO*/ 

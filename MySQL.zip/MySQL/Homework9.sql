CREATE DATABASE Airport
GO
USE Airport
GO

CREATE TABLE Airport(
Airport_Code int NOT NULL,
City varchar(25) NOT NULL,
States varchar(25) NOT NULL,
Name varchar(25) NOT NULL,
CONSTRAINT PK_Airport PRIMARY KEY(Airport_Code),
CONSTRAINT UK_Airport UNIQUE (Name)
)
GO

CREATE TABLE Airplane_Type(
Type_Name varchar(25) NOT NULL,
Max_seats varchar(25) NOT NULL,
Company varchar(25) NOT NULL,
CONSTRAINT PK_Airplane_Type PRIMARY KEY(Type_Name)
)
GO

CREATE TABLE CanLand(
Airport_code int,
Type_name varchar(25),
CONSTRAINT PK_Airplane_Can_Land_Airplane_Type PRIMARY KEY (Airport_code,Type_name),
CONSTRAINT FK_Airport_code_CandLand FOREIGN KEY (Airport_code) REFERENCES Airport(Airport_code)
ON UPDATE CASCADE
ON DELETE CASCADE,
CONSTRAINT FK_Airplane_Type_CandLand FOREIGN KEY (Type_name) REFERENCES Airplane_Type(Type_Name)
ON UPDATE CASCADE
ON DELETE CASCADE
)
GO

CREATE TABLE Airplane(
Type_Name varchar(25) NOT NULL,
AirplaneID int NOT NULL,
Total_no_of_seats int NOT NULL,
CONSTRAINT PK_Airport PRIMARY KEY(AirplaneID),
CONSTRAINT FK_Airplane FOREIGN KEY(Type_Name) REFERENCES Airplane_Type(Type_Name)
           ON UPDATE CASCADE
           ON DELETE NO ACTION
)
GO

CREATE TABLE Flight(
Number int NOT NULL,
Airline varchar(25) NOT NULL,
WeekDays varchar(8) NOT NULL,
CONSTRAINT PK_Flight PRIMARY KEY(Number)
)
GO


CREATE TABLE Flight_Leg(
Leg_no int NOT NULL,
Airport_Code int NOT NULL,
FlightNumber int NOT NULL,
Dep_Airplane_code int NOT NULL,
Arival_Airplane_code int NOT NULL,
Scheduled_dep_time date NOT NULL,
Scheduled_arr_time date NOT NULL,
CONSTRAINT PK_Flight_Leg_Airport PRIMARY KEY (Leg_no, FlightNumber),
CONSTRAINT FK_Flight_Leg_Dep_Airplane_code FOREIGN KEY (Dep_Airplane_code)REFERENCES Airport (Airport_Code),
CONSTRAINT FK_Flight_Leg_Arival_Airplane_code FOREIGN KEY (Arival_Airplane_code)REFERENCES Airport (Airport_Code),
CONSTRAINT FK_Flight_Leg_Flight FOREIGN KEY (FlightNumber)REFERENCES Flight (Number),
CONSTRAINT FK_Flight_LEG FOREIGN KEY (Airport_Code) REFERENCES Airport (Airport_Code)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO

CREATE TABLE Leg_Instance(
Leg_no int NOT NULL,
Airplane_id int NOT NULL,
FlightNumber int NOT NULL,

DateOfFlight varchar(25) NOT NULL, 
No_of_avail_seats int NOT NULL,
Arr_time datetime NOT NULL,
Dep_time datetime NOT NULL,
Dep_Airplane_code int NOT NULL,
Arival_Airplane_code int NOT NULL,
CONSTRAINT PK_Leg_Instance_Flight_Leg PRIMARY KEY (Leg_no,FlightNumber,DateOfFlight),
CONSTRAINT FK_Leg_Instance FOREIGN KEY (Leg_no,FlightNumber) REFERENCES Flight_Leg (Leg_no,FlightNumber)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO

CREATE TABLE Seat(
Leg_no int NOT NULL,
Customer_name  varchar(25) NOT NULL,
Cphone varchar(15)  NOT NULL,
FlightNumber int NOT NULL,
DateOfFlight varchar(25) NOT NULL, 
Seat_no varchar(8) NOT NULL,
CONSTRAINT PK_Leg_Instance_Flight_Leg PRIMARY KEY (Leg_no,FlightNumber,DateOfFlight,Seat_no),
CONSTRAINT FK_Seat FOREIGN KEY (Leg_no,FlightNumber,DateOfFlight) REFERENCES Leg_Instance (Leg_no,FlightNumber,DateOfFlight)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO

CREATE TABLE Fare(
Code int NOT NULL,
Amount decimal(4,2) NOT NULL,
Restrictions varchar(25),
FightNumber int NOT NULL,
CONSTRAINT PK_Fare PRIMARY KEY (Code,FightNumber),
CONSTRAINT FK_Fare FOREIGN KEY (FightNumber) REFERENCES Flight (Number)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO
USE AutoDealer
GO

ALTER PROCEDURE procAddService	
	@ServiceID	char(2), 
	@ServiceName varchar(50),
	@AllottedTime varchar(10),
	@Cost decimal(6,2)
AS
BEGIN
	INSERT INTO Services(ServiceID,ServiceName,AllottedTime,Cost) 
	VALUES (@ServiceID, @ServiceName, @AllottedTime, @Cost)
 END 


ALTER PROCEDURE procUpdateService
	@ServiceID			char(2),
	@ServiceName        varchar(50),
	@AllottedTime       varchar(10),
	@Cost              decimal(6,2)
AS
BEGIN
	UPDATE Services
	SET ServiceName=@ServiceName,AllottedTime=@AllottedTime,Cost=@Cost 
	WHERE ServiceID = @ServiceID
END

CREATE PROCEDURE procDeleteServiceByID 
	@ServiceID	char(2),
	@ServiceName varchar(50),
	@AllottedTime       int,
	@Cost               decimal(6,2)
AS
BEGIN
	DELETE FROM Services
	WHERE ServiceID = @ServiceID
END

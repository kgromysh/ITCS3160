USE AutoDealer3
GO

/*Problem 1*/
SELECT Mechanics.FirstName, Mechanics.LastName, ServiceAppointments.AppointmentDate, COUNT(*) AS 'Number of APPTS'
FROM Mechanics JOIN ServiceAppointments ON
     Mechanics.ID=ServiceAppointments.MechanicID
GROUP BY Mechanics.FirstName, Mechanics.LastName, ServiceAppointments.AppointmentDate


/*Problem 2*/

SELECT Customers.FirstName,Customers.LastName, Cars.Year, Cars.Manufacturer,Cars.Model,
       ServiceAppointments.AppointmentDate, ServiceAppointments.AppointmentTime
FROM Customers JOIN ServiceAppointments ON
Customers.ID=ServiceAppointments.CustomerID JOIN Cars ON
ServiceAppointments.vehicleID=Cars.vehicleID
ORDER BY ServiceAppointments.AppointmentDate, ServiceAppointments.AppointmentTime

/*Problem 3*/

 SELECT Services.ServiceName, COUNT(AppointmentServices.ServiceID) AS '# of times Preformed', SUM(Services.Cost) AS 'Total Cost'
 FROM Services JOIN AppointmentServices ON
 Services.ServiceID=AppointmentServices.ServiceID JOIN ServiceAppointments ON
 AppointmentServices.AppointmentID= ServiceAppointments.AppointmentID
 GROUP BY Services.ServiceName
 ORDER BY 'Total Cost' DESC

 /*Problem 4*/
SELECT Customers.FirstName,Customers.LastName,
COUNT(AppointmentServices.ServiceID) AS '# of times Preformed', SUM(Services.Cost) AS 'Total Cost'
FROM Customers JOIN ServiceAppointments ON
Customers.ID=ServiceAppointments.CustomerID JOIN AppointmentServices ON
ServiceAppointments.AppointmentID=AppointmentServices.AppointmentID JOIN Services ON
AppointmentServices.ServiceID= Services.ServiceID
GROUP BY FirstName, LastName

/*Bonus Problem */